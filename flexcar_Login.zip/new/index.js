(function () {

    // access the DOM elements
    let loginButton = document.getElementById('loginButton');
    let emailHelper = document.getElementById('loginEmailHelper');
    let passwordHelper = document.getElementById('loginPasswordHelper');

    let emailField = document.getElementById('loginEmail');
    let passwordField = document.getElementById('loginPassword');

    // handling of input fields on typing
    [emailField, passwordField].forEach((node) => {
        node.addEventListener('input', function () {
            emailHelper.innerText = '';
            passwordHelper.innerText = '';
        })
    })


    // on login click
    loginButton.addEventListener('click', function (e) {

        emailHelper.innerText = '';
        passwordHelper.innerText = '';
        let emailInputValue = (document.getElementById('loginEmail').value || '').trim();
        let passwordInputValue = (document.getElementById('loginPassword').value || '');

        //validate if email is empty
        if (!emailInputValue) {
            emailHelper.innerText = 'Please enter email';
            return;
        }

        //validate if password is empty
        if (!passwordInputValue) {
            passwordHelper.innerText = 'Please enter Password';
            return;
        }

        // validate email
        if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailInputValue))) {
            emailHelper.innerText = 'Invalid email';
            return;
        }

        // validate password
        if (passwordInputValue.length < 8) {
            passwordHelper.innerText = 'Please enter at least 8 characters in password';
            return;
        }

        // on success
        alert("success");
    })
})()